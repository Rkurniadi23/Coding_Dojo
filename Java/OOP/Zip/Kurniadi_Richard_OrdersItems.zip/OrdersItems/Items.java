import java.util.ArrayList;

public class Items {
    public String name;
    public double price;
    
}