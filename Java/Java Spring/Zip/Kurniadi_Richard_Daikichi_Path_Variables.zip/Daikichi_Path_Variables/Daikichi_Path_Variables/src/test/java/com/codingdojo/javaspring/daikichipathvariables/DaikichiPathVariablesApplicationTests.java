package com.codingdojo.javaspring.daikichipathvariables;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DaikichiPathVariablesApplicationTests {

	@Test
	void contextLoads() {
	}

}
