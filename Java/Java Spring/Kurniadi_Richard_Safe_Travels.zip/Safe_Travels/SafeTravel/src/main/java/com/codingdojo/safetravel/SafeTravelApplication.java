package com.codingdojo.safetravel;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SafeTravelApplication {

	public static void main(String[] args) {
		SpringApplication.run(SafeTravelApplication.class, args);
	}

}
