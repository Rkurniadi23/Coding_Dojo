package com.codingdojo.safetravel;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SafeTravelApplicationTests {

	@Test
	void contextLoads() {
	}

}
