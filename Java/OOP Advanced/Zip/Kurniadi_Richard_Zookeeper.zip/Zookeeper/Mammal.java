class Mammal{
    public int energy = 100;

    public Mammal(int energy){
        this.energy = energy;
    }
}

