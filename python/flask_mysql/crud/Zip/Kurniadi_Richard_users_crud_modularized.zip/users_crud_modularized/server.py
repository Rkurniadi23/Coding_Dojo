from users_crud_modularized.controllers import users

from users_crud_modularized import app

if __name__ == "__main__":
    app.run(debug=True)