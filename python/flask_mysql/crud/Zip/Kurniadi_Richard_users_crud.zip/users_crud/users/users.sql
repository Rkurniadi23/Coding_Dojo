select * from users
order by first_name desc;