select dojo_id from ninjas
where id = 9;